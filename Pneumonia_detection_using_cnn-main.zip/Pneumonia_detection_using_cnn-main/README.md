# Pneumonia_detection_using_cnn
 detection of pneumonia using cnn input based on x-rays of lungs
